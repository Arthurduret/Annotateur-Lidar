# LiDAR Annotate — Plateforme collaborative

Plateforme web d'annotation LiDAR pour équipes, inspirée de CVAT.

## Déploiement GitHub Pages

1. Créer un repo GitHub (ex: `lidar-annotate`)
2. Uploader les 3 fichiers : `index.html`, `annotator.html`, `README.md`
3. Settings → Pages → Source: `main` branch → Save
4. URL: `https://<username>.github.io/lidar-annotate`

## Fichiers
- `index.html` — Dashboard principal (projets, tâches, équipe, kanban)
- `annotator.html` — Annotateur 3D LiDAR

## Fonctionnalités
- ✅ Gestion de projets et tâches
- ✅ Workflow : À faire → En cours → En revue → Validé
- ✅ Kanban board
- ✅ Gestion d'équipe (rôles : Admin, Annotateur, Relecteur)
- ✅ Import/Export datasets PCD + ZIP Supervisely
- ✅ Annotateur 3D intégré (multi-frames, cuboïdes, export CVAT)
- ✅ Données persistées en localStorage
